let planetName = 'Земля';
confirm("Ты живешь на планете: " + planetName + '?');