let a = "Hello world!!!";

console.log(a);
alert(a);

