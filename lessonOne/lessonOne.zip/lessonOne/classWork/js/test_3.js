let youName = 'somebody';
youName = prompt('Как вас зовут?');
alert('Привет ' + youName);