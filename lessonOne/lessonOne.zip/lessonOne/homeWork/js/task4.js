// 4. Получить от пользователя данные о пользователе: имя, фамилию, возраст. Обработать их и вывести на экран.

let name, sername, age;

name = prompt("Enter your name:");
sername = prompt("Enter your sername:");
age = prompt("Enter your age:");

alert(`Hello ${name} ${sername} you are ${age} years old?`);